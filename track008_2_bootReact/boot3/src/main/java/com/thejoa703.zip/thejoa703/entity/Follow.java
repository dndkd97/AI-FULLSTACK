package com.thejoa703.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="FOLLOWS", uniqueConstraints = @UniqueConstraint(columnNames = {"FOLLOWER_ID","FOLLOWEE_ID"}))
public class Follow {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE ,generator = "follow_seq")
	@SequenceGenerator(name="follow_seq",sequenceName = "FOLLOW_SEQ",allocationSize = 1)
	private Long id;
	
	@Column(name="CREATEDAT",nullable=false)
	private LocalDateTime createdAt;
	
	@PrePersist void onCreate() { this.createdAt=LocalDateTime.now(); } 
	
	public Follow(AppUser follower, AppUser followee) {
		super();
		this.follower = follower;
		this.followee = followee;
	}

	@ManyToOne(fetch=FetchType.LAZY) // 1. 연관된 엔티티(AppUser) 당장가져오는게 아니고
	@JoinColumn(name="FOLLOWER_ID",nullable=false)
	AppUser follower; // @ManyToOne 보는사람
	
	@ManyToOne(fetch=FetchType.LAZY) // 2. 실제 객체사용하는 시점에서 쿼리 실행 ,불필요한 join 줄이기
	@JoinColumn(name="FOLLOWEE_ID",nullable=false)
	AppUser followee; // @ManyToOne 보여지는 사람

}
